package com.example.floatingtext

import android.app.*
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var sizeText: TextView
    private var size = 30f
    private var color = Color.rgb(255,164,25)
    private var locked = false
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pref=getSharedPreferences("overlay", MODE_PRIVATE); size=pref.getFloat("size",30f); color=pref.getInt("color",Color.rgb(255,164,25)); locked=pref.getBoolean("locked",false)
        val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,24,22,24); setBackgroundColor(Color.rgb(248,248,250)) }
        root.addView(TextView(this).apply { text="浮動文字 Overlay"; textSize=25f; setTextColor(Color.BLACK) })
        root.addView(TextView(this).apply { text="每一行都是獨立浮動文字。點擊文字可直接編輯，拖曳可移動。"; textSize=14f; setTextColor(Color.DKGRAY); setPadding(0,8,0,14) })
        editor=EditText(this).apply { hint="每行輸入一段文字"; minLines=3; maxLines=8; setText(pref.getString("lines","直播文字\n第二行文字")); setTextColor(Color.BLACK); setPadding(12,12,12,12); gravity=android.view.Gravity.TOP }
        root.addView(editor,LinearLayout.LayoutParams(-1,-2))
        root.addView(TextView(this).apply { text="文字顏色"; textSize=16f; setTextColor(Color.BLACK); setPadding(0,18,0,6) })
        val colors= listOf("橘黃" to Color.rgb(255,164,25),"金黃" to Color.rgb(255,205,55),"紅" to Color.RED,"白" to Color.WHITE,"藍" to Color.rgb(70,150,255))
        val row=LinearLayout(this)
        colors.forEach { (label,c)-> row.addView(Button(this).apply { text=label; setOnClickListener { color=c; save(); refresh() } },LinearLayout.LayoutParams(0,-2,1f)) }; root.addView(row)
        sizeText=TextView(this).apply { setTextColor(Color.BLACK); textSize=16f; setPadding(0,16,0,0) }; root.addView(sizeText)
        root.addView(SeekBar(this).apply { max=68; progress=(size-12).toInt().coerceIn(0,68); setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener { override fun onProgressChanged(s:SeekBar?,p:Int,user:Boolean){size=(p+12).toFloat();sizeText.text="字體大小：${size.toInt()} sp"; if(user){save();refresh()} }; override fun onStartTrackingTouch(s:SeekBar?){}; override fun onStopTrackingTouch(s:SeekBar?){} }) })
        sizeText.text="字體大小：${size.toInt()} sp"
        root.addView(Button(this).apply { text="顯示／更新浮動文字"; setOnClickListener { save(); startOverlay() } },LinearLayout.LayoutParams(-1,-2).apply { topMargin=18 })
        root.addView(Button(this).apply { text=if(locked) "解除直播鎖定" else "啟用直播鎖定"; setOnClickListener { locked=!locked; pref.edit().putBoolean("locked",locked).apply(); text=if(locked) "解除直播鎖定" else "啟用直播鎖定"; val i=Intent(this@MainActivity,OverlayService::class.java).setAction(OverlayService.ACTION_LOCK).putExtra("locked",locked); startService(i) } })
        root.addView(Button(this).apply { text="停止浮動文字"; setOnClickListener { stopService(Intent(this@MainActivity,OverlayService::class.java)) } })
        root.addView(TextView(this).apply { text="首次使用需允許「顯示在其他應用程式上層」。直播鎖定後，文字不會因點擊而進入編輯。"; textSize=12f; setTextColor(Color.GRAY); setPadding(0,14,0,0) })
        setContentView(ScrollView(this).apply { addView(root) })
    }
    private fun save(){ getSharedPreferences("overlay",MODE_PRIVATE).edit().putString("lines",editor.text.toString()).putFloat("size",size).putInt("color",color).putBoolean("locked",locked).apply() }
    private fun refresh(){ if(Settings.canDrawOverlays(this)) startService(Intent(this,OverlayService::class.java).setAction(OverlayService.ACTION_REFRESH)) }
    private fun startOverlay(){ if(!Settings.canDrawOverlays(this)){startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")));Toast.makeText(this,"請允許顯示在其他應用程式上層，再按一次顯示",Toast.LENGTH_LONG).show();return}; val i=Intent(this,OverlayService::class.java); if(Build.VERSION.SDK_INT>=26) startForegroundService(i) else startService(i) }
}
