package com.example.floatingtext

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val views = mutableListOf<TextView>()
    private val params = mutableListOf<WindowManager.LayoutParams>()
    private var locked = false

    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager; channel() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf() }
            ACTION_REFRESH -> rebuild()
            ACTION_LOCK -> { locked = intent.getBooleanExtra("locked", false); applyTouchMode() }
            else -> { startForeground(7, notification()); rebuild() }
        }
        return START_STICKY
    }
    private fun notification(): Notification {
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_edit).setContentTitle("浮動文字正在顯示").setContentText("點擊文字可直接編輯；直播時可鎖定").setContentIntent(pi).setOngoing(true).build()
    }
    private fun rebuild() {
        clearViews()
        val p = getSharedPreferences("overlay", MODE_PRIVATE)
        val lines = p.getString("lines", "直播文字\n第二行文字")!!.split('\n')
        val size = p.getFloat("size", 30f)
        val color = p.getInt("color", Color.rgb(255, 164, 25))
        lines.forEachIndexed { i, line ->
            if (line.isBlank()) return@forEachIndexed
            val tv = TextView(this).apply {
                text = line; textSize = size; typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
                setPadding(5, 4, 5, 4); setLayerType(View.LAYER_TYPE_SOFTWARE, null)
                paint.style = Paint.Style.FILL_AND_STROKE; paint.strokeWidth = 1.2f; setTextColor(color)
                paint.shader = LinearGradient(0f, 0f, 0f, textSize * 1.4f, intArrayOf(Color.rgb(255,205,55), color), null, Shader.TileMode.CLAMP)
                setShadowLayer(3f, 2f, 3f, Color.BLACK)
                setOnClickListener { if (!locked) editLine(i, text.toString()) }
            }
            val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = 180 + i * (size * 1.7f).toInt() }
            attachDrag(tv, lp)
            views.add(tv); params.add(lp); wm.addView(tv, lp)
        }
        applyTouchMode()
    }
    private fun attachDrag(v: TextView, lp: WindowManager.LayoutParams) {
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                if (locked) return true
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { val dx=e.rawX-sx; val dy=e.rawY-sy; if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>8) moved=true; lp.x += dx.toInt(); lp.y += dy.toInt(); wm.updateViewLayout(v,lp); sx=e.rawX; sy=e.rawY; return true }
                    MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
                }; return true
            }
        })
    }
    private fun editLine(index: Int, old: String) {
        val input = EditText(this).apply { setText(old); setSelection(text.length); textSize = 18f; setSingleLine(false) }
        val dialog = AlertDialog.Builder(this).setTitle("編輯這一行").setView(input)
            .setNegativeButton("取消", null).setPositiveButton("完成") { _, _ ->
                val p=getSharedPreferences("overlay", MODE_PRIVATE); val lines=p.getString("lines", "")!!.split('\n').toMutableList()
                while (lines.size <= index) lines.add(""); lines[index]=input.text.toString(); p.edit().putString("lines", lines.joinToString("\n")).apply(); rebuild()
            }.create()
        dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
        dialog.setOnShowListener { input.requestFocus(); input.post { (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(input, InputMethodManager.SHOW_IMPLICIT) } }
        dialog.show(); dialog.window?.setType(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY)
    }
    private fun applyTouchMode() { views.forEach { it.isClickable = !locked; it.alpha = 1f } }
    private fun clearViews() { views.forEach { try { wm.removeView(it) } catch (_: Exception) {} }; views.clear(); params.clear() }
    private fun channel() { if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(CHANNEL,"浮動文字",NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy() { clearViews(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null
    companion object { const val ACTION_STOP="STOP"; const val ACTION_REFRESH="REFRESH"; const val ACTION_LOCK="LOCK"; const val CHANNEL="floating_overlay" }
}
